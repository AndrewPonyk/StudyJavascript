/*! h5ive.js | (c) Kyle Simpson | MIT License: http://getify.mit-license.org */
(function(a){a.h5={};})(this);(function(a){if(!a)throw new Error("xhr.h5ive: core.h5ive required but missing.");a.xhr=function(b){};})(this.h5);
