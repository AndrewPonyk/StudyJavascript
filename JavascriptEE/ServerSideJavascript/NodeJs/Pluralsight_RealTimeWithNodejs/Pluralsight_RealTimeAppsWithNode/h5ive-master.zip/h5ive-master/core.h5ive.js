/*! core.h5ive.js | (c) Kyle Simpson | MIT License: http://getify.mit-license.org */

(function(global){

	global.h5 = {
		// TODO: fill in core API functions
	};

})(this);
