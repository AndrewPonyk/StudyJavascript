var video = h5.video({
	// ...
});

document.appendChild(video.element());